js-rummy
========

A simple Rummy game using jQuery
