//global game specs
var suits = ['Clubs', 'Spades', 'Diamonds', 'Hearts']
var numbers = ['Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Jack', 'Queen', 'King', 'Ace'];
var numCards = suits.length * numbers.length, handSize = 7, dealt = false;

function resetGame() {
	//set all buttons/messages back to initial state
	$('#win_message').css({'visibility':'', 'font-size':''});
	$('#rules_message').css({'visibility':'', 'pointer-events':''});
	$('#start_button')[0].textContent = 'Deal Cards';
	//generate all 52 cards as a stack on the upper left
	dealt = false;
	$('div.pile > .inner').empty(); //the inner div of a pile holds its cards
	$stack = $('#stack');
	//make an array of the numbers 0-51
	var cards = []
	for(var i = 0; i < numCards; i++) cards.push(i);
	//and randomly iterate over it to generate the .card divs in the deck, until it is empty - this way the deck is shuffled
	for(var i = 0; i < numCards; i++) {
		var c = Math.floor(Math.random() * cards.length);
		var s = Math.floor(cards[c] / numbers.length);
		var n = cards[c] % numbers.length;
		cards.splice(c, 1);
		text = n < 9 ? ''+(n+2) : numbers[n].charAt(0);
		text += suits[s].charAt(0);
		//create the card div
		$card = $('<div class="card" suit="' + suits[s] + '" number="' + numbers[n] + '"></div>');
		$card.attr('dealt','false');
		$card.attr('moving','false');
		$card.attr('mousePressed','false');
		$card.append('<div><div>' + text + '</div></div>'); 
		$('#stack > .inner').append($card);
		
		$card.data('targetCard', $card.clone().css('visibility','hidden'));


	}


}

function cardName($card) {
	return $card.attr('number') + ' of ' + $card.attr('suit');
}

//determine a card's current pile
function getPile($card) {
	return $card.parents('.pile').attr('id');
}

function deal() {
	//deal the top 7 cards from the stack
	for(var i = 0; i < handSize; i++) dealCard(i*150);
	dealt = true;
	$('#start_button')[0].textContent = 'Reset Game';
}
//send the top card from the deck to the hand
function dealCard(delay=0) {
	var $topCard = topCard();
	if($topCard === undefined) {
		console.log('No more cards to deal!');
		return;
	}
	$topCard.attr('dealt','true');
	moveCard($topCard, 'hand', delay);
}
function topCard() {
	var $stack = $('#stack > .inner > .card[dealt="false"]');
	if($stack.length === 0) return undefined;
	return $stack.last();
}


function moveCard($card, pile, delay=0, $before=undefined, from={}) {

	/* STEP 1 */
	var $curPile = $('#' + getPile($card) + ' > .inner'), $movingCards = $card;
	var $newPile = $('#' + pile + ' > .inner');
	$card.attr('moving','true');
	//if either the source or destination pile is a line of cards rather than a stack, some cards may need to shift left/right
	if($curPile.css('position') !== 'absolute' || $newPile.css('position') !== 'absolute') {
		//if moving from one pile to another...
		if(!$curPile.is($newPile)) {
			//the cards to my right in the source pile will shift left by one slot
			$movingCards = $movingCards.add($card.nextAll('.card[moving="false"]').filter(function() {
				return typeof $(this).data('targetCard') != 'undefined'; }));
			//and the cards to my right in the destination pile will shift right by one slot
			if($before !== undefined && $newPile.css('position') !== 'absolute')
				$movingCards = $movingCards.add($before.add($before.nextAll('.card[moving="false"]').filter(function() {
					return typeof $(this).data('targetCard') != 'undefined'; })));
		}else { //if moving within a pile, the cards between my current and destination slots will shift
			var start, end; //first identify those slots
			if($before !== undefined) {
				if($before.index() < $card.index()) {
					start = $before.index();
					end = $card.index()+1;
				}else {
					start = $card.index();
					end = $before.index();
				}
			}else {
				start = $card.index();
				end = $curPile.children().length;
			}
			//then find all non-moving, non-target cards within that range of slots (non-target means I have a target)
			$range = $curPile.children('.card[moving="false"]');
			$range = $range.filter(function() { return typeof $(this).data('targetCard') != 'undefined'; }).slice(start,end);
			$movingCards = $movingCards.add($range);
		}
	}
	
	/* STEP 2 */
	//cache each card's current position so it isn't changed by starting to animate the one to the left of it
	$movingCards.each(function(i) {
		if($(this).is($card) && from.hasOwnProperty('top')) $(this).data('curPos', from);
		else $(this).data('curPos', $(this).position());
	});
	//switch each card to absolute position for the duration of the animation...
	$movingCards.each(function(i) {
		var $this = $(this), pos = $(this).data('curPos');
		$this.css('position', 'absolute');
		if($this.is($card)) $this.css('z-index','1');
		$this.css({'top': pos.top+'px', 'left': pos.left+'px'}); //make sure it stays in place when switching to absolute
	});
	
	/* STEP 3 */
	//get all the target cards in place so we know their positions
	$movingCards.each(function(i) {
		var $this = $(this), $target = $this.data('targetCard').detach().css({'position':'','top':'0','left':'0'});
		if(!($this.is($card))) $target.insertAfter($this);
		else {
			if($before === undefined) $target.appendTo($newPile);
			else $target.insertBefore($before);
		}
	});
	
	/* STEP 4 */
	//do the animation!
	$movingCards.each(function(i) {
		var $this = $(this), $target = $this.data('targetCard');
		var pos = $(this).data('curPos');
		var deltaTop = $target.offset().top - $this.offset().top, deltaLeft = $target.offset().left - $this.offset().left;
		$this.stop().delay(delay).animate(
			{
				top:'+='+deltaTop+'px',
				left:'+='+deltaLeft+'px'
			},
			{
				duration: $this.is($card) && !from.hasOwnProperty('top') ? 1000 : 500,
				complete: function() {
					$this.attr('moving','false');
					$this.css({'position':'', 'z-index':'', 'top':'0', 'left':'0'});
					if($this.is($card) && !($newPile.is($curPile))) $target.replaceWith($this);
					else $target.replaceWith($this);
					if(getPile($this) === 'hand') {
						$this.draggable('option','disabled',false);
						$this.draggable('option','scope','hand');
						$this.setDroppableScope('hand');
					}else if(getPile($this) === 'discard') {
						$this.draggable('option','disabled',true);
					}
					if($('.card[moving="true"]').length === 0) checkWin();
				}
			}
		);
	});
}




//all the setup is done from here
$(document).ready(function() {

	resetGame();
	
	//need this to allow right-clicks on cards
	$('#card_panel')[0].oncontextmenu = function(){return false;};

	//make sure no card thinks the mouse is pressed on it when it isn't
	$(document).mouseup(function(event) {
		$('.card[mousePressed="true"]').attr('mousePressed','false');
	});

	//start button toggles to the Reset button once the game is started
	$('#start_button').html('Deal Cards');
	$('#start_button').click(function() {
		if(!dealt) deal();
		else resetGame();
	});

});

