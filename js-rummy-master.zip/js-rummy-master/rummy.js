
var suits = ['Clubs', 'Spades', 'Diamonds', 'Hearts']
var numbers = ['Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Jack', 'Queen', 'King', 'Ace'];
var numCards = suits.length * numbers.length, handSize = 13, dealt = false;

function resetGame() {
	$('#win_message').css({'visibility':'', 'font-size':''});
	$('#rules_message').css({'visibility':'', 'pointer-events':''});
	$('#start_button')[0].textContent = 'Deal Cards';
	dealt = false;
	$('div.pile > .inner').empty(); 
	$stack = $('#stack');
	var cards = []
	for(var i = 0; i < numCards; i++) cards.push(i);
	for(var i = 0; i < numCards; i++) {
		var c = Math.floor(Math.random() * cards.length);
		var s = Math.floor(cards[c] / numbers.length);
		var n = cards[c] % numbers.length;
		cards.splice(c, 1);
		text = n < 9 ? ''+(n+2) : numbers[n].charAt(0);
		text += suits[s].charAt(0);
		//create the card div
		$card = $('<div class="card" suit="' + suits[s] + '" number="' + numbers[n] + '"></div>');
		$card.attr('dealt','false');
		$card.attr('moving','false');
		$card.attr('mousePressed','true');
		$card.append('<div><div>' + text + '</div></div>'); 
		$('#stack > .inner').append($card);
		
		$card.data('targetCard', $card.clone().css('visibility','hidden'));


	}


}

function cardName($card) {
	return $card.attr('number') + ' of ' + $card.attr('suit');
}

function getPile($card) {
	return $card.parents('.pile').attr('id');
}

function deal() {
	for(var i = 0; i < handSize; i++) dealCard(i*150);
	dealt = true;
	$('#start_button')[0].textContent = 'Reset Game'; 
}
function dealCard(delay=0) {
	var $topCard = topCard();
	if($topCard === undefined) {
		console.log('No more cards to deal!');
		return;
	}
	$topCard.attr('dealt','true');
	moveCard($topCard, 'hand', delay);
}
function topCard() {
	var $stack = $('#stack > .inner > .card[dealt="false"]');
	if($stack.length === 0) return undefined;
	return $stack.last();
}


function moveCard($card, pile, delay=0, $before=undefined, from={}) {

	var $curPile = $('#' + getPile($card) + ' > .inner'), $movingCards = $card;
	var $newPile = $('#' + pile + ' > .inner');
	$card.attr('moving','true');
	if($curPile.css('position') !== 'absolute' || $newPile.css('position') !== 'absolute') {
		if(!$curPile.is($newPile)) {
			$movingCards = $movingCards.add($card.nextAll('.card[moving="false"]').filter(function() {
				return typeof $(this).data('targetCard') != 'undefined'; }));
			if($before !== undefined && $newPile.css('position') !== 'absolute')
				$movingCards = $movingCards.add($before.add($before.nextAll('.card[moving="false"]').filter(function() {
					return typeof $(this).data('targetCard') != 'undefined'; })));
		}else { 
			var start, end;
			if($before !== undefined) {
				if($before.index() < $card.index()) {
					start = $before.index();
					end = $card.index()+1;
				}else {
					start = $card.index();
					end = $before.index();
				}
			}else {
				start = $card.index();
				end = $curPile.children().length;
			}
			$range = $curPile.children('.card[moving="false"]');
			$range = $range.filter(function() { return typeof $(this).data('targetCard') != 'undefined'; }).slice(start,end);
			$movingCards = $movingCards.add($range);
		}
	}
	$movingCards.each(function(i) {
		if($(this).is($card) && from.hasOwnProperty('top')) $(this).data('curPos', from);
		else $(this).data('curPos', $(this).position());
	});
	$movingCards.each(function(i) {
		var $this = $(this), pos = $(this).data('curPos');
		$this.css('position', 'absolute');
		if($this.is($card)) $this.css('z-index','1');
		$this.css({'top': pos.top+'px', 'left': pos.left+'px'}); //make sure it stays in place when switching to absolute
	});
	
	$movingCards.each(function(i) {
		var $this = $(this), $target = $this.data('targetCard').detach().css({'position':'','top':'0','left':'0'});
		if(!($this.is($card))) $target.insertAfter($this);
		else {
			if($before === undefined) $target.appendTo($newPile);
			else $target.insertBefore($before);
		}
	});
	
	$movingCards.each(function(i) {
		var $this = $(this), $target = $this.data('targetCard');
		var pos = $(this).data('curPos');
		var deltaTop = $target.offset().top - $this.offset().top, deltaLeft = $target.offset().left - $this.offset().left;
		$this.stop().delay(delay).animate(
			{
				top:'+='+deltaTop+'px',
				left:'+='+deltaLeft+'px'
			},
			{
				duration: $this.is($card) && !from.hasOwnProperty('top') ? 1000 : 500,
				complete: function() {
					$this.attr('moving','false');
					$this.css({'position':'', 'z-index':'', 'top':'0', 'left':'0'});
					if($this.is($card) && !($newPile.is($curPile))) $target.replaceWith($this);
					else $target.replaceWith($this);
					if(getPile($this) === 'hand') {
						$this.draggable('option','disabled',false);
						$this.draggable('option','scope','hand');
						$this.setDroppableScope('hand');
					}else if(getPile($this) === 'discard') {
						$this.draggable('option','disabled',true);
					}
					if($('.card[moving="true"]').length === 0) checkWin();
				}
			}
		);
	});
}


$(document).ready(function() {

	resetGame();


	$('#start_button').html('Deal Cards');
	$('#start_button').click(function() {
		if(!dealt) deal();
	});

});

